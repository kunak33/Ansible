﻿This directory or its subdirectories should contain OpenVPN
configuration files each having an extension of .ovpn.

When OpenVPN GUI is started configs in this directory are added
to the list of available connections.
